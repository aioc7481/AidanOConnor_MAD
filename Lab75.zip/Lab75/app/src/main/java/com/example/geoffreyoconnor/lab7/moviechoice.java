package com.example.geoffreyoconnor.lab7;

public class moviechoice {
    private String filmschoice;
    private String filmchoiceURL;

    private void setFilmInfo(Integer mood) {
        switch (mood) {
            case 0: //sad
                filmschoice = "The Place Beyond The Pines";
                filmchoiceURL = "https://www.imdb.com/title/tt1817273/?ref_=nv_sr_1";
                break;
            case 1: //inspired
                filmschoice = "Forrest Gump";
                filmchoiceURL = "https://www.imdb.com/title/tt0109830/?ref_=nv_sr_2";
                break;
            case 2: //romantic
                filmschoice = "Titanic";
                filmchoiceURL = "https://www.imdb.com/title/tt0120338/?ref_=nv_sr_2";
                break;
            case 3: //happy
                filmschoice = "Finding Nemo";
                filmchoiceURL = "https://www.imdb.com/title/tt0266543/?ref_=nv_sr_1";
                break;
            case 4: //musical
                filmschoice = "Rent";
                filmchoiceURL = "https://www.imdb.com/title/tt0294870/?ref_=nv_sr_1";
                break;
            default:
                filmschoice = "none";
                filmchoiceURL = "https://www.imdb.com";
        }
    }

    public void setFilmchoice(Integer mood) {
        setFilmInfo(mood);
    }

    public void setFilmchoiceURL(Integer mood) {
        setFilmInfo(mood);
    }

    public String getFilmchoice() {
        return filmschoice;
    }

    public String getFilmchoiceURL() {
        return filmchoiceURL;
    }
}
