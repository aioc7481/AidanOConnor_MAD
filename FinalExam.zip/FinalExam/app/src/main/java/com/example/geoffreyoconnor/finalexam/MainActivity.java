package com.example.geoffreyoconnor.finalexam;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends Activity {


    String popURl;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);



        Button buttons = findViewById(R.id.button3);
        View.OnClickListener onclick2 = new View.OnClickListener() {
            public void onClick(View view) {
                FindPizza(view);
            }
        };
        buttons.setOnClickListener(onclick2);

        Button button2 = findViewById(R.id.button2);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view) {
                loadWebSite(view);
            }
        };

        button2.setOnClickListener(onclick);
    }
    private void FindPizza(View view) {
        Spinner moodSpinner = findViewById(R.id.spinner);
        Integer moodspin = moodSpinner.getSelectedItemPosition();

        String toppings = "";
        CheckBox checkbox1 = findViewById(R.id.checkBox5);
        CheckBox checkbox2 = findViewById(R.id.checkBox6);
        CheckBox checkbox3 = findViewById(R.id.checkBox7);
        CheckBox checkbox4 = findViewById(R.id.checkBox8);

        if (checkbox1.isChecked()) {
            toppings += " Sausage";
        }
        if (checkbox2.isChecked()) {
            toppings += " Pepperoni";
        }
        if (checkbox3.isChecked()) {
            toppings += " Onions";
        }
        if (checkbox4.isChecked()) {
            toppings += " Mushrooms";
        }

        RadioGroup decade = findViewById(R.id.radioGroup3);
        int dec_id = decade.getCheckedRadioButtonId();
        String decc = "";

        if (dec_id == -1) {
            Context context = getApplicationContext();
            CharSequence toaster = "Please select a size";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, toaster, duration);
            toast.show();

        } else {
            if (dec_id == R.id.radioButton4) {
                decc = "Small";
            } else if (dec_id == R.id.radioButton5) {
                decc = "Medium";
            } else if (dec_id == R.id.radioButton6) {
                decc = "Large";
            }
        }
        String sauce = "";
        ToggleButton tb = findViewById(R.id.toggleButton2);
        if (tb.isChecked()){
            sauce = "Red";
        }
        else {
            sauce = "White";
        }


        TextView showza = findViewById(R.id.textView3);
        Spinner crustkind = findViewById(R.id.spinner);
        Integer crust = crustkind.getSelectedItemPosition();

        String pop = "";

        if (crust == 0) {
            pop = "Boss Lady Pizza";
            popURl = "https://bossladypizza.com/";
        }
        else if (crust == 1) {
            pop = "Pizzeria Locale";
            popURl = "https://localeboulder.com/";
        }
        else if (crust == 2) {
            pop = "Back Country Pizza";
            popURl = "https://backcountrypizzaandtaphouse.info/";
        }


        showza.setText("Your " + decc + " Pizza with toppings: " + toppings + " & the " + sauce + " sauce." + "I reccomend you eat at " + pop + ".");
    }




    private void loadWebSite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(popURl));
        startActivity(intent);
    }
}
