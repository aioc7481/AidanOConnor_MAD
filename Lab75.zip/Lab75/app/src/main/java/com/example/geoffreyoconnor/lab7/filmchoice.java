package com.example.geoffreyoconnor.lab7;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.TextView;

public class filmchoice extends Activity {

    private String filmschoice;
    private String filmchoiceURL;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_filmchoice);
        Intent intent = getIntent();
        filmschoice = intent.getStringExtra("filmName");
        filmchoiceURL = intent.getStringExtra("filmURL");

        Log.i("film received", filmschoice);
        Log.i("url received", filmchoiceURL);

        TextView messageView = findViewById(R.id.textView3);
        messageView.setText("You Should Watch " + filmschoice);

        Button button2 = findViewById(R.id.button2);

        View.OnClickListener onclick = new View.OnClickListener(){
            public void onClick(View view) {
                loadWebSite(view);
            }
        };

        button2.setOnClickListener(onclick);
    }

    private void loadWebSite(View view) {
        Intent intent = new Intent(Intent.ACTION_VIEW);
        intent.setData(Uri.parse(filmchoiceURL));
        startActivity(intent);
    }
}
