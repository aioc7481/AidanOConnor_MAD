package com.example.geoffreyoconnor.lab7;

import android.app.Activity;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Spinner;

public class MainActivity extends Activity {

    private moviechoice mychoice = new moviechoice();


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        Button button = findViewById(R.id.button);
        View.OnClickListener onclick = new View.OnClickListener() {
            public void onClick(View view) {
                findFilm(view);
            }
        };
        button.setOnClickListener(onclick);
    }

    private void findFilm(View view) {
        Spinner moodSpinner = findViewById(R.id.spinner);
        Integer moodspin = moodSpinner.getSelectedItemPosition();
        mychoice.setFilmchoice(moodspin);

        String givenmovie = mychoice.getFilmchoice();
        String givenmovieURL = mychoice.getFilmchoiceURL();
        Log.i("film", givenmovie);
        Log.i("url", givenmovieURL);

        Intent intent = new Intent(this, filmchoice.class);



        intent.putExtra("filmName", givenmovie);
        intent.putExtra("filmURL", givenmovieURL);

        startActivity(intent);

    }
}
