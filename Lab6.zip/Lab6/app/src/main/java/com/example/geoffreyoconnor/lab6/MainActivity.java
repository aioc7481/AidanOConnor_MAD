package com.example.geoffreyoconnor.lab6;

import android.content.Context;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;
import android.widget.ToggleButton;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
    }
    public void favColor(View view) {
        EditText name = findViewById(R.id.editText2);

        CheckBox shade1 = findViewById(R.id.checkBox4);
        Boolean dark = shade1.isChecked();
        ToggleButton toggle = findViewById(R.id.toggleButton);
        Boolean yell = toggle.isChecked();
        CheckBox shade2 = findViewById(R.id.checkBox5);
        Boolean light = shade2.isChecked();
        TextView finalcolor = findViewById(R.id.message);
        String namevalue = name.getText().toString();
        //finalcolor.setText(namevalue + )

        String favcolor;

        RadioGroup redgreenblue = findViewById(R.id.radioGroup2);
        int rgb_pick = redgreenblue.getCheckedRadioButtonId();

        if (rgb_pick == -1) {
            Context context = getApplicationContext();
            CharSequence msg = "Please pick Red, Green, or Blue";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, msg, duration);
            toast.show();
        }
        if (shade1.isChecked() == false && shade2.isChecked()) {
            Context context = getApplicationContext();
            CharSequence msg2 = "Please check white or black";
            int duration = Toast.LENGTH_SHORT;
            Toast toast = Toast.makeText(context, msg2, duration);
            toast.show();
        }
        else {
            if (yell) {
                if (shade1.isChecked()) {
                    if(rgb_pick == R.id.radioButton6) {
                        favcolor = "Orange";
                    }
                    else if (rgb_pick == R.id.radioButton7) {
                        favcolor = "lime green";
                    }
                    else {
                        favcolor = "Olive green";
                    }
                }
                else {
                    if(rgb_pick == R.id.radioButton6) {
                        favcolor = "Pumpkin orange";
                    }
                    else if (rgb_pick == R.id.radioButton7) {
                        favcolor = "Cactus Green";
                    }
                    else {
                        favcolor = "Military Green";
                    }
                }
            }
            else {
                if (shade1.isChecked()) {
                    if(rgb_pick == R.id.radioButton6) {
                        favcolor = "Wine red";
                    }
                    else if (rgb_pick == R.id.radioButton7) {
                        favcolor = "brown";
                    }
                    else {
                        favcolor = "Purple";
                    }
                }
                else {
                    if(rgb_pick == R.id.radioButton6) {
                        favcolor = "pink";
                    }
                    else if (rgb_pick == R.id.radioButton7) {
                        favcolor = "Grey";
                    }
                    else {
                        favcolor = "Violet";
                    }
                }
            }
            finalcolor.setText(namevalue + " Your Favorite Color is " + favcolor + "!");
        }

    }
}
