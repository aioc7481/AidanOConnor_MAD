#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;


int main (int argc, char *argv[]) {
  string array[45465];
  string filename = argv[1];
  ifstream data;
  data.open(filename.c_str());
  string temp;
  int i = 0;
  //string search = "Crime";
  size_t pos;
  string search2 = "Animation";
  size_t pos2;
  string search3 = "Comedy";
  size_t pos3;
  string search4 = "Drama";
  size_t pos4;
  string search5 = "Romance";
  size_t pos5;
  string search6 = "Thriller";
  size_t pos6;
  string search7 = "Horror";
  size_t pos7;
  string search8 = "Action";
  size_t pos8;
  //string search9 = "Fantasy";
  size_t pos9;
  string search10 = "Science Fiction";
  size_t pos10;
  //string search11 = "History";
  size_t pos11;
  //string search12 = "Family";
  size_t pos12;
  //string search13 = "Foreign";
  size_t pos13;
  string search14 = "Documentary";
  size_t pos14;
  //string search15 = "Mystery";
  size_t pos15;
  string search16 = "Adventure";
  size_t pos16;
  //string search17 = "Western";
  size_t pos17;

  if(data.is_open()) {

      while (getline(data, temp)) {
      /*  pos=temp.find(search); // search
      if(pos!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "0";
        }*/
        pos2=temp.find(search2); // search
      if(pos2!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "0";
        }
        pos3=temp.find(search3); // search
      if(pos3!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "1";
        }
        pos4=temp.find(search4); // search
      if(pos4!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "2";
        }
        pos5=temp.find(search5); // search
      if(pos5!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "3";
        }
        pos6=temp.find(search6); // search
      if(pos6!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "4";
        }
        pos7=temp.find(search7); // search
      if(pos7!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "5";
        }
        pos8=temp.find(search8); // search
      if(pos8!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "6";
        }
        /*pos9=temp.find(search9); // search
      if(pos9!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "8";
        }*/
        pos10=temp.find(search10); // search
      if(pos10!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "7";
        }
      /*  pos11=temp.find(search11); // search
      if(pos11!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "10";
        }
        pos12=temp.find(search12); // search
      if(pos12!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "11,";
        }
        pos13=temp.find(search13); // search
      if(pos13!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "12,";
        }*/
        pos14=temp.find(search14); // search
      if(pos14!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "8";
        }
        /*pos15=temp.find(search15); // search
      if(pos15!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "14,";
        }*/
        pos16=temp.find(search16); // search
      if(pos16!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "9";
        }
    /*    pos17=temp.find(search17); // search
      if(pos17!=string::npos) // string::npos is returned if string is not found
        {
            array[i] += "16,";
        }*/
/*
        if(temp == "Crime") {
          array[i] += "Crime";
          cout << "helloo" << endl;
        }
        if (temp == "Animation"){
          array[i] += "Animation";
          cout << "helloo" << endl;
        }
        if (temp == "Comedy") {
          array[i] += "Comedy";
          cout << "helloo" << endl;
        }
        if (temp == "Drama") {
          array[i] += "Drama";
          cout << "helloo" << endl;
        }
        if (temp == "Romance") {
          array[i] += "Romance";
          cout << "helloo" << endl;
        }
        if (temp == "Thriller"){
          array[i] += "Thriller";
          cout << "helloo" << endl;
        }
        if (temp == "Horror"){
          array[i] += "Horror";
          cout << "helloo" << endl;
        }
        if (temp == "Action"){
          array[i] += "Action";
          cout << "helloo" << endl;
        }
        if (temp == "Fantasy") {
          array[i] += "Fantasy";
          cout << "helloo" << endl;
        }
        if (temp == "Science Fiction") {
          array[i] += "Science Fiction";
          cout << "helloo" << endl;
        }
        if (temp == "History") {
          array[i] += "History";
          cout << "helloo" << endl;
        }
        if (temp == "Family") {
          array[i] += "Family";
          cout << "helloo" << endl;
        }
        if (temp == "Foreign") {
          array[i] += "Foreign";
          cout << "helloo" << endl;
        }
        if (temp == "Documentary") {
          array[i] += "Documentary";
          cout << "helloo" << endl;
        }*/
        i++;
        //cout << temp << endl;
      }
    data.close();
  }
  ofstream myfile ("example3.txt");
  if (myfile.is_open())
  {
    for (int i = 0; i < 45465; i++) {
      myfile << array[i] << endl;
    }

  }
  myfile.close();

}
