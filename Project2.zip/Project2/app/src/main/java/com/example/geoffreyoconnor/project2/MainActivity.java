package com.example.geoffreyoconnor.project2;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.RadioGroup;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.io.BufferedReader;
import java.io.DataInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.io.UnsupportedEncodingException;
import java.lang.reflect.Array;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Random;

public class MainActivity extends Activity {
    TextView messageView; //= findViewById(R.id.textView);
    Button b_read;
    //String movie;

    public String getdec() {
        RadioGroup decade = findViewById(R.id.radioGroup2);
        int dec_id = decade.getCheckedRadioButtonId();
        String decc = "";

        if (dec_id == -1) {
            Context context = getApplicationContext();
            CharSequence toaster = "Please select a decade";
            int duration = Toast.LENGTH_SHORT;

            Toast toast = Toast.makeText(context, toaster, duration);
            toast.show();
            //decc = "";
        } else {
            if (dec_id == R.id.radioButton) {
                decc = "0";
            } else if (dec_id == R.id.radioButton2) {
                decc = "1";
            } else if (dec_id == R.id.radioButton3) {
                decc = "2";
            } else if (dec_id == R.id.radioButton4) {
                decc = "3";
            } else if (dec_id == R.id.radioButton5) {
                decc = "4";
            } else if (dec_id == R.id.radioButton6) {
                decc = "5";
            } else if (dec_id == R.id.radioButton7) {
                decc = "6";
            }

        }
        return decc;
    }


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        b_read = (Button) findViewById(R.id.button);
        messageView = (TextView) findViewById(R.id.textView);



        b_read.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String[] films;
                String[] text;
                //String[] theyears;
                //String o = "";

                try {
                    InputStream is = getAssets().open("example3.txt");
                    InputStream film = getAssets().open("example2.txt");
                    InputStream years = getAssets().open("example4.txt");

                    BufferedReader br = new BufferedReader(new InputStreamReader(is));
                    BufferedReader br2 = new BufferedReader(new InputStreamReader(film));
                    BufferedReader br3 = new BufferedReader(new InputStreamReader(years));

                    ArrayList<String> list = new ArrayList<String>();
                    ArrayList<String> list2 = new ArrayList<String>();
                    ArrayList<String> list4 = new ArrayList<String>();

                    String strLine;
                    String year;
                    String stars;

                    while ((strLine = br.readLine()) != null) {

                        list.add(strLine);

                    }

                    while ((stars = br2.readLine()) != null) {

                        list2.add(stars);

                    }
                    while ((year = br3.readLine()) != null) {

                        list4.add(year);

                    }

                    Spinner moodSpinner = findViewById(R.id.spinner2);
                    Integer moodspin = moodSpinner.getSelectedItemPosition();
                    String numberAsString = Integer.toString(moodspin);


                    String happy = getdec();


                    ArrayList<String> list3 = new ArrayList<String>();
                    films = (String[])list2.toArray(new String[list2.size()]);
                    text = (String[])list.toArray(new String[list.size()]);


                        //for (int i = 0; i < list.size(); i++) {
                            for (int j = 0; j < list4.size(); j++) {


                                //if (list.get(i).contains(numberAsString)) {
                                    if (list4.get(j).contains(happy) && list.get(j).contains(numberAsString)) {
                                        list3.add(films[j]);
                                    }



                        }

                        String[] finals;
                        finals = (String[]) list3.toArray(new String[list3.size()]);


                        Random rand = new Random();
                        int n = rand.nextInt(list3.size()) + 1;
                        messageView.setText(finals[n]);
                            //movie = finals[n];







                } catch (IOException ex) {
                    ex.printStackTrace();
                }

            }
        });


    }




}
