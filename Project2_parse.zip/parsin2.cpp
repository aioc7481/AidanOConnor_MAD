#include <iostream>
#include <string>
#include <sstream>
#include <fstream>

using namespace std;


int main (int argc, char *argv[]) {
  string array[45466];
  string filename = argv[1];
  ifstream data;
  data.open(filename.c_str());
  string temp;
  int i = 0;
  //string search = "Crime";

  if(data.is_open()) {

      while (getline(data, temp)) {
        int j = temp.length() - 2;
        if (temp[j] == '5') {
          array[i] = "0";
        }
        else if (temp[j] == '6') {
          array[i] = "1";
        }
        else if (temp[j] == '7') {
          array[i] = "2";
        }
        else if (temp[j] == '8') {
          array[i] = "3";
        }
        else if (temp[j] == '9') {
          array[i] = "4";
        }
        else if (temp[j] == '0') {
          array[i] = "5";
        }
        else if (temp[j] == '1') {
          array[i] = "6";
        }
        i++;
      }
    data.close();
  }
  ofstream myfile ("example4.txt");
  if (myfile.is_open())
  {
    for (int i = 0; i < 45466; i++) {
      myfile << array[i] << endl;
      //cout << array[i] << endl;
    }

  }
  myfile.close();


}
